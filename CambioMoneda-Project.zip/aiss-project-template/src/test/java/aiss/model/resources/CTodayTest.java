package aiss.model.resources;


import static org.junit.Assert.*;

import java.io.UnsupportedEncodingException;

import org.junit.Test;

import aiss.model.ctoday.CambioSearch;


public class CTodayTest {

	@Test
	public void test() throws UnsupportedEncodingException {
		String source = "EUR";
		String target = "USD";
		String quantity= "5";
		CTodayResource ctoday = new CTodayResource();
		CambioSearch ctodayResults = ctoday.getCambio(source, target, quantity);
		
		assertNotNull("The search returned null", ctodayResults);
		assertNotNull("The search returned null", ctodayResults.getResult());
		assertFalse("The number of matches for "+ quantity + "is zero", ctodayResults.getResult().getAmount()==0);
		
		System.out.println("El cambio de " + quantity + " returned " + ctodayResults.getResult().getAmount()+" "+target);
	}

}
