package aiss.model.resources;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.restlet.resource.ClientResource;

import aiss.model.ctoday.CambioSearch;

public class CTodayResource {

	private static final String CTODAY_API_KEY = "4259|xf1iZ7iJySwSLF7nox0vZMUHXT9pe*vo";
	private static final Logger log = Logger.getLogger(CTodayResource.class.getName());
	
	public CambioSearch getCambio(String source, String target, String quantity) throws UnsupportedEncodingException{
		
		
		String uri = "https://api.cambio.today/v1/quotes/"+ URLEncoder.encode(source, "UTF-8") 
					+"/"+ URLEncoder.encode(target, "UTF-8") 
					+"/json?quantity="+ URLEncoder.encode(quantity, "UTF-8") 
					+"&key="+ CTODAY_API_KEY;
		
		log.log(Level.FINE, "Flickr URI: "+ uri);
		
		ClientResource cr = new ClientResource(uri);
		CambioSearch CtodaySearch = cr.get(CambioSearch.class);
		
		
	    return CtodaySearch;
	}
}
