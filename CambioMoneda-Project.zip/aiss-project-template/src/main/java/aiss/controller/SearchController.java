package aiss.controller;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import aiss.model.ctoday.CambioSearch;
import aiss.model.resources.CTodayResource;

/**
 * Servlet implementation class SearchController
 */
public class SearchController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private static final Logger log = Logger.getLogger(SearchController.class.getName());
	 
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchController() {
        super();
    }
    
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    
    
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {	
		
		String source = request.getParameter("source");
		String target = request.getParameter("target");
		String quantity = request.getParameter("quantity");
		RequestDispatcher rd = null;
		
		// Obtener cambio de moneda
			log.log(Level.FINE, "Obtener la moneda origen" + source);
			log.log(Level.FINE, "Obtener la moneda destino" + target);
			log.log(Level.FINE, "Obtener la cantidad" + quantity);
			CTodayResource ctoday = new CTodayResource();
			CambioSearch ctodayResults = ctoday.getCambio(source, target, quantity);
			
			
			if (ctodayResults!=null){
				rd = request.getRequestDispatcher("/success.jsp");
				request.setAttribute("monedas", ctodayResults.getResult());	
				
			} else {
				log.log(Level.SEVERE, "CToday object: " + ctodayResults);
				rd = request.getRequestDispatcher("/error.jsp");
			}
			rd.forward(request, response);

	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
}
