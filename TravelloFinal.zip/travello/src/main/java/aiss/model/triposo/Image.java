
package aiss.model.triposo;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "source_id",
    "source_url",
    "owner",
    "owner_url",
    "license",
    "caption",
    "attribution",
    "sizes"
})
public class Image {

    @JsonProperty("source_id")
    private String sourceId;
    @JsonProperty("source_url")
    private String sourceUrl;
    @JsonProperty("owner")
    private String owner;
    @JsonProperty("owner_url")
    private String ownerUrl;
    @JsonProperty("license")
    private Object license;
    @JsonProperty("caption")
    private Object caption;
    @JsonProperty("attribution")
    private Attribution attribution;
    @JsonProperty("sizes")
    private Sizes sizes;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("source_id")
    public String getSourceId() {
        return sourceId;
    }

    @JsonProperty("source_id")
    public void setSourceId(String sourceId) {
        this.sourceId = sourceId;
    }

    @JsonProperty("source_url")
    public String getSourceUrl() {
        return sourceUrl;
    }

    @JsonProperty("source_url")
    public void setSourceUrl(String sourceUrl) {
        this.sourceUrl = sourceUrl;
    }

    @JsonProperty("owner")
    public String getOwner() {
        return owner;
    }

    @JsonProperty("owner")
    public void setOwner(String owner) {
        this.owner = owner;
    }

    @JsonProperty("owner_url")
    public String getOwnerUrl() {
        return ownerUrl;
    }

    @JsonProperty("owner_url")
    public void setOwnerUrl(String ownerUrl) {
        this.ownerUrl = ownerUrl;
    }

    @JsonProperty("license")
    public Object getLicense() {
        return license;
    }

    @JsonProperty("license")
    public void setLicense(Object license) {
        this.license = license;
    }

    @JsonProperty("caption")
    public Object getCaption() {
        return caption;
    }

    @JsonProperty("caption")
    public void setCaption(Object caption) {
        this.caption = caption;
    }

    @JsonProperty("attribution")
    public Attribution getAttribution() {
        return attribution;
    }

    @JsonProperty("attribution")
    public void setAttribution(Attribution attribution) {
        this.attribution = attribution;
    }

    @JsonProperty("sizes")
    public Sizes getSizes() {
        return sizes;
    }

    @JsonProperty("sizes")
    public void setSizes(Sizes sizes) {
        this.sizes = sizes;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
