package aiss.model.resource;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.restlet.resource.ClientResource;

import aiss.model.ticketmaster.TicketSearch;

public class TicketResource {
	

		private static final String TICKET_API_KEY = "KD82AL23dVrfQ6BALO24NNEJ5okRFeCT";		// TODO: Change this API KEY for your personal Key
		private static final Logger log = Logger.getLogger(TicketResource.class.getName());

		
		public TicketSearch getTicketMasterEvents(String city) throws UnsupportedEncodingException{
			
			String queryFormatted=URLEncoder.encode(city,"UTF-8");
			String uri="http://app.ticketmaster.com/discovery/v2/events.json?city="+queryFormatted+"&apikey="+TICKET_API_KEY+"&callback=myFunction";
			// TODO: Perform search in TicketMaster
			
			log.log(Level.FINE,"TicketMaster URI"+ uri);
			
			ClientResource cr= new ClientResource(uri);
			TicketSearch ticketMasterSearch= cr.get(TicketSearch.class);
		    return ticketMasterSearch;
		}
		
	}


