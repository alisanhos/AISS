package aiss.model.resource;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.restlet.resource.ClientResource;

import aiss.model.triposo.RestaurantsSearch;


public class TriposoResource {
    private static final Logger log = Logger.getLogger(TriposoResource.class.getName());
    private static final String APIkey = "6rdpni95vt2w1kuon7jxiw7umr5l1i9d";
    private static final String secretAccount = "RE1HISQD";


    public RestaurantsSearch getTriposoRestaurants(String city) throws UnsupportedEncodingException{

        String queryFormatted = URLEncoder.encode(city,"UTF-8");
        String uri="http://www.triposo.com/api/20200405/poi.json?tag_labels=poitype-Restaurant&poitype-Restaurant_score=%3E=3&location_id=" + queryFormatted + "&order_by=-score&fields=name,images,coordinates,score&account=" + secretAccount + "&token=" + APIkey;
        // TODO: Perform search in Triposo

        log.log(Level.FINE,"Triposo URI"+ uri);

        ClientResource cr= new ClientResource(uri);
        
        RestaurantsSearch triposoSearch= cr.get(RestaurantsSearch.class);
        return triposoSearch;
    }
}
