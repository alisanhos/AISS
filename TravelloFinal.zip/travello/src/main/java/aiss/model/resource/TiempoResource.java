package aiss.model.resource;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.restlet.resource.ClientResource;

import aiss.model.weather.ClimaSearch;



public class TiempoResource {

	private static final String Tiempo_API_KEY = "c72416ff0fa95793f273a4af14b50aa4";  // TODO: Change this API KEY for your personal Key
	private static final Logger log = Logger.getLogger(TiempoResource.class.getName());
	
	public ClimaSearch getClima(String query) throws UnsupportedEncodingException {

		String q = URLEncoder.encode(query,"UTF-8");
		String uri = "http://api.openweathermap.org/data/2.5/weather?q="+q+"&appid="+Tiempo_API_KEY;
		log.log(Level.FINE,"OWM URI"+ uri);
		ClientResource cr = new ClientResource(uri);
		ClimaSearch owmSearch = cr.get(ClimaSearch.class);
	    return owmSearch;
	}
}
