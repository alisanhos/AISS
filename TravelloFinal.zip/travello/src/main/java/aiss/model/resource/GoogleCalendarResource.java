package aiss.model.resource;


import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;
import org.restlet.data.ChallengeResponse;
import org.restlet.data.ChallengeScheme;
import org.restlet.data.MediaType;
import org.restlet.resource.ClientResource;
import org.restlet.resource.ResourceException;

import com.google.api.client.util.DateTime;

import aiss.model.calendars.Calendar;
import aiss.model.calendars.End;
import aiss.model.calendars.Events;
import aiss.model.calendars.Item;
import aiss.model.calendars.Start;




public class GoogleCalendarResource {
	
	  private static final Logger log = Logger.getLogger(GoogleCalendarResource.class.getName());

	  private final String access_token;
	  //www antes era content
	  private final String baseURL = "https://www.googleapis.com/calendar/v3/calendars";

	  public GoogleCalendarResource(String access_token) {
	        this.access_token = access_token;
	    }
	  public Calendar insertCalendar(String summary) {	
			ClientResource cr=new ClientResource(baseURL);
			ChallengeResponse chr = new ChallengeResponse(ChallengeScheme.HTTP_OAUTH_BEARER);
			chr.setRawValue(access_token);
			cr.setChallengeResponse(chr);
			Calendar datosParaCrear=new Calendar();
			datosParaCrear.setSummary(summary);
			Calendar contenido=cr.post(datosParaCrear,Calendar.class);
			return contenido;

	  }
	  public Item insertEventInCalendar(String CalendarId, String summary, String descripcion, String dateini ,String dateend) throws UnsupportedEncodingException{
		   
		  Start start = new Start();
		  start.setDate(dateini);
		  End end= new End();
		  end.setDate(dateend);
		  
		  ClientResource cr=new ClientResource(baseURL+"/"+CalendarId+"/events?alt=json");
		  ChallengeResponse chr = new ChallengeResponse(ChallengeScheme.HTTP_OAUTH_BEARER);
		  chr.setRawValue(access_token);
		  cr.setChallengeResponse(chr);
		  
		  Item evento=new Item();
		  evento.setSummary(summary);
		  evento.setDescription(descripcion);
		  evento.setStart(start);
		  evento.setEnd(end);
		  

		  Item contenido=cr.post(evento,Item.class);
		  return contenido;

	  }
	  
		  public Calendar getCalendar() {	
			ClientResource cr=new ClientResource("https://www.googleapis.com/calendar/v3/calendars/primary");
			ChallengeResponse chr = new ChallengeResponse(ChallengeScheme.HTTP_OAUTH_BEARER);
			chr.setRawValue(access_token);
			cr.setChallengeResponse(chr);
			Calendar contenido=cr.get(Calendar.class);
			return contenido;

	  }
	  
	  public boolean deleteEvent(String CalendarID,String eventID) {

	        ClientResource cr = null;
	        boolean result = true;
	        try {
	            cr = new ClientResource("https://www.googleapis.com/calendar/v3/calendars/"+CalendarID+"/events/"+eventID);
	            ChallengeResponse chr = new ChallengeResponse(ChallengeScheme.HTTP_OAUTH_BEARER);
	            chr.setRawValue(access_token);
	  		  	cr.setChallengeResponse(chr);
	            cr.delete();
	        } catch (ResourceException re) {
	            log.warning("Error when deleting file: " + cr.getResponse().getStatus());
	            result = false;
	        }
	        return result;
	  }
	  
	  public boolean updateEvent(Item event ,String CalendarID, String eventID) {

	        ClientResource cr = null;
	        boolean result = false;
	        try {
	            cr = new ClientResource("https://www.googleapis.com/calendar/v3/calendars/"+CalendarID+"/events/"+eventID);
	            ChallengeResponse chr = new ChallengeResponse(ChallengeScheme.HTTP_OAUTH_BEARER);
	            chr.setRawValue(access_token);
	  		  	cr.setChallengeResponse(chr);
	            cr.put(event);
	            result=true;
	        } catch (ResourceException re) {
	            log.warning("Error when updating file: " + cr.getResponse().getStatus());
	            result = false;
	        }
	        return result;
	    }
	  
	  public Events getListEvents(String CalendarID){
		  Events le= null;
		  ClientResource cr=new ClientResource(baseURL+"/"+CalendarID+"/events?alt=json");
		  ChallengeResponse chr = new ChallengeResponse(ChallengeScheme.HTTP_OAUTH_BEARER);
		  chr.setRawValue(access_token);
		  cr.setChallengeResponse(chr);
		  le = cr.get(Events.class);
		  
		return le;
		  
	  }
}
