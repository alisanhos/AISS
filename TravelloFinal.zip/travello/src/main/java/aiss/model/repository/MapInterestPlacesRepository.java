package aiss.model.repository;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;


import aiss.model.api.InterestPlaces;

public class MapInterestPlacesRepository implements InterestPlacesRepository{
	Map<String, InterestPlaces> placesMap;
	private static MapInterestPlacesRepository instance=null;
	private int index=0;			// Index to create playlists and songs' identifiers.
	
	
	public static MapInterestPlacesRepository getInstance() {
		
		if (instance==null) {
			instance = new MapInterestPlacesRepository();
			instance.init();
		}
		
		return instance;
	}
	
	public void init() {
		
		
		placesMap = new HashMap<String,InterestPlaces>();
		
		// Create songs
		InterestPlaces plazaDeCuba=new InterestPlaces();
		plazaDeCuba.setName("plaza De Cuba");
		plazaDeCuba.setDescription("Es una plaza perfecta para poder ver el río mientras tomas unos churros");
		plazaDeCuba.setScore("3.7");
		plazaDeCuba.setCity("Seville");
		addPlace(plazaDeCuba);
		
		InterestPlaces parquePrincipes=new InterestPlaces();
		parquePrincipes.setName("parque de los Principes");
		parquePrincipes.setDescription("Es un parque perfecto para disfrutar de las vistas con unos amigos");
		parquePrincipes.setScore("3.2");
		parquePrincipes.setCity("Seville");
		addPlace(parquePrincipes);
		
		InterestPlaces laGiralda=new InterestPlaces();
		laGiralda.setName("laGiralda");
		laGiralda.setDescription("Es un patrimonio arquitectonico gotico para culturizarse");
		laGiralda.setScore("3.8");
		laGiralda.setCity("Seville");
		addPlace(laGiralda);
		
		InterestPlaces torrePegi=new InterestPlaces();
		torrePegi.setName("torre Pegi");
		torrePegi.setDescription("Es una gran torre donde puedes hacer compras chulas");
		torrePegi.setScore("4.2");
		torrePegi.setCity("Seville");
		addPlace(torrePegi);
		
		InterestPlaces lasSetas=new InterestPlaces();
		lasSetas.setName("las Setas de Sevilla");
		lasSetas.setDescription("un lugar fascinante");
		lasSetas.setScore("4.0");
		lasSetas.setCity("Seville");
		addPlace(lasSetas);
		
		
		
		
	}
	
	@Override
	public InterestPlaces addPlace(InterestPlaces s) {
		String id = "s" + index++;	
		s.setId(id);
		placesMap.put(id,s);
		return s;
		
	}

	@Override
	public Collection<InterestPlaces> getAllPlaces() {
		return placesMap.values();
	}

	@Override
	public InterestPlaces getPlace(String placeId) {
		return placesMap.get(placeId);
	}

	@Override
	public void updatePlace(InterestPlaces s) {
		placesMap.put(s.getId(), s);
		
	}

	@Override
	public void deletePlace(String placeId) {
		placesMap.remove(placeId);
		
	}

}
