package aiss.model.repository;

import java.util.Collection;

import aiss.model.api.InterestPlaces;



public interface InterestPlacesRepository {
	public InterestPlaces addPlace(InterestPlaces s);
	public Collection<InterestPlaces> getAllPlaces();
	public InterestPlaces getPlace(String placeId);
	public void updatePlace(InterestPlaces s);
	public void deletePlace(String placeId);
}
