
package aiss.model.ticketmaster;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "phoneNumberDetail",
    "openHoursDetail",
    "acceptedPaymentDetail",
    "willCallDetail"
})
public class BoxOfficeInfo {

    @JsonProperty("phoneNumberDetail")
    private String phoneNumberDetail;
    @JsonProperty("openHoursDetail")
    private String openHoursDetail;
    @JsonProperty("acceptedPaymentDetail")
    private String acceptedPaymentDetail;
    @JsonProperty("willCallDetail")
    private String willCallDetail;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("phoneNumberDetail")
    public String getPhoneNumberDetail() {
        return phoneNumberDetail;
    }

    @JsonProperty("phoneNumberDetail")
    public void setPhoneNumberDetail(String phoneNumberDetail) {
        this.phoneNumberDetail = phoneNumberDetail;
    }

    @JsonProperty("openHoursDetail")
    public String getOpenHoursDetail() {
        return openHoursDetail;
    }

    @JsonProperty("openHoursDetail")
    public void setOpenHoursDetail(String openHoursDetail) {
        this.openHoursDetail = openHoursDetail;
    }

    @JsonProperty("acceptedPaymentDetail")
    public String getAcceptedPaymentDetail() {
        return acceptedPaymentDetail;
    }

    @JsonProperty("acceptedPaymentDetail")
    public void setAcceptedPaymentDetail(String acceptedPaymentDetail) {
        this.acceptedPaymentDetail = acceptedPaymentDetail;
    }

    @JsonProperty("willCallDetail")
    public String getWillCallDetail() {
        return willCallDetail;
    }

    @JsonProperty("willCallDetail")
    public void setWillCallDetail(String willCallDetail) {
        this.willCallDetail = willCallDetail;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
