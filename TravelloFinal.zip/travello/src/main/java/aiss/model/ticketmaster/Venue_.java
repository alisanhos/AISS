
package aiss.model.ticketmaster;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "name",
    "type",
    "id",
    "test",
    "url",
    "locale",
    "images",
    "postalCode",
    "timezone",
    "city",
    "state",
    "country",
    "address",
    "markets",
    "dmas",
    "boxOfficeInfo",
    "parkingDetail",
    "generalInfo",
    "upcomingEvents",
    "ada",
    "_links"
})
public class Venue_ {

    @JsonProperty("name")
    private String name;
    @JsonProperty("type")
    private String type;
    @JsonProperty("id")
    private String id;
    @JsonProperty("test")
    private Boolean test;
    @JsonProperty("url")
    private String url;
    @JsonProperty("locale")
    private String locale;
    @JsonProperty("images")
    private List<Image_> images = null;
    @JsonProperty("postalCode")
    private String postalCode;
    @JsonProperty("timezone")
    private String timezone;
    @JsonProperty("city")
    private City city;
    @JsonProperty("state")
    private State state;
    @JsonProperty("country")
    private Country country;
    @JsonProperty("address")
    private Address address;
    @JsonProperty("markets")
    private List<Market> markets = null;
    @JsonProperty("dmas")
    private List<Dma> dmas = null;
    @JsonProperty("boxOfficeInfo")
    private BoxOfficeInfo boxOfficeInfo;
    @JsonProperty("parkingDetail")
    private String parkingDetail;
    @JsonProperty("generalInfo")
    private GeneralInfo generalInfo;
    @JsonProperty("upcomingEvents")
    private UpcomingEvents upcomingEvents;
    @JsonProperty("ada")
    private Ada ada;
    @JsonProperty("_links")
    private Links_ links;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("name")
    public String getName() {
        return name;
    }

    @JsonProperty("name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("type")
    public String getType() {
        return type;
    }

    @JsonProperty("type")
    public void setType(String type) {
        this.type = type;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    @JsonProperty("test")
    public Boolean getTest() {
        return test;
    }

    @JsonProperty("test")
    public void setTest(Boolean test) {
        this.test = test;
    }

    @JsonProperty("url")
    public String getUrl() {
        return url;
    }

    @JsonProperty("url")
    public void setUrl(String url) {
        this.url = url;
    }

    @JsonProperty("locale")
    public String getLocale() {
        return locale;
    }

    @JsonProperty("locale")
    public void setLocale(String locale) {
        this.locale = locale;
    }

    @JsonProperty("images")
    public List<Image_> getImages() {
        return images;
    }

    @JsonProperty("images")
    public void setImages(List<Image_> images) {
        this.images = images;
    }

    @JsonProperty("postalCode")
    public String getPostalCode() {
        return postalCode;
    }

    @JsonProperty("postalCode")
    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    @JsonProperty("timezone")
    public String getTimezone() {
        return timezone;
    }

    @JsonProperty("timezone")
    public void setTimezone(String timezone) {
        this.timezone = timezone;
    }

    @JsonProperty("city")
    public City getCity() {
        return city;
    }

    @JsonProperty("city")
    public void setCity(City city) {
        this.city = city;
    }

    @JsonProperty("state")
    public State getState() {
        return state;
    }

    @JsonProperty("state")
    public void setState(State state) {
        this.state = state;
    }

    @JsonProperty("country")
    public Country getCountry() {
        return country;
    }

    @JsonProperty("country")
    public void setCountry(Country country) {
        this.country = country;
    }

    @JsonProperty("address")
    public Address getAddress() {
        return address;
    }

    @JsonProperty("address")
    public void setAddress(Address address) {
        this.address = address;
    }

    @JsonProperty("markets")
    public List<Market> getMarkets() {
        return markets;
    }

    @JsonProperty("markets")
    public void setMarkets(List<Market> markets) {
        this.markets = markets;
    }

    @JsonProperty("dmas")
    public List<Dma> getDmas() {
        return dmas;
    }

    @JsonProperty("dmas")
    public void setDmas(List<Dma> dmas) {
        this.dmas = dmas;
    }

    @JsonProperty("boxOfficeInfo")
    public BoxOfficeInfo getBoxOfficeInfo() {
        return boxOfficeInfo;
    }

    @JsonProperty("boxOfficeInfo")
    public void setBoxOfficeInfo(BoxOfficeInfo boxOfficeInfo) {
        this.boxOfficeInfo = boxOfficeInfo;
    }

    @JsonProperty("parkingDetail")
    public String getParkingDetail() {
        return parkingDetail;
    }

    @JsonProperty("parkingDetail")
    public void setParkingDetail(String parkingDetail) {
        this.parkingDetail = parkingDetail;
    }

    @JsonProperty("generalInfo")
    public GeneralInfo getGeneralInfo() {
        return generalInfo;
    }

    @JsonProperty("generalInfo")
    public void setGeneralInfo(GeneralInfo generalInfo) {
        this.generalInfo = generalInfo;
    }

    @JsonProperty("upcomingEvents")
    public UpcomingEvents getUpcomingEvents() {
        return upcomingEvents;
    }

    @JsonProperty("upcomingEvents")
    public void setUpcomingEvents(UpcomingEvents upcomingEvents) {
        this.upcomingEvents = upcomingEvents;
    }

    @JsonProperty("ada")
    public Ada getAda() {
        return ada;
    }

    @JsonProperty("ada")
    public void setAda(Ada ada) {
        this.ada = ada;
    }

    @JsonProperty("_links")
    public Links_ getLinks() {
        return links;
    }

    @JsonProperty("_links")
    public void setLinks(Links_ links) {
        this.links = links;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
