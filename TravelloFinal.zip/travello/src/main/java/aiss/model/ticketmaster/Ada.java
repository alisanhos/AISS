
package aiss.model.ticketmaster;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "adaPhones",
    "adaCustomCopy",
    "adaHours"
})
public class Ada {

    @JsonProperty("adaPhones")
    private String adaPhones;
    @JsonProperty("adaCustomCopy")
    private String adaCustomCopy;
    @JsonProperty("adaHours")
    private String adaHours;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("adaPhones")
    public String getAdaPhones() {
        return adaPhones;
    }

    @JsonProperty("adaPhones")
    public void setAdaPhones(String adaPhones) {
        this.adaPhones = adaPhones;
    }

    @JsonProperty("adaCustomCopy")
    public String getAdaCustomCopy() {
        return adaCustomCopy;
    }

    @JsonProperty("adaCustomCopy")
    public void setAdaCustomCopy(String adaCustomCopy) {
        this.adaCustomCopy = adaCustomCopy;
    }

    @JsonProperty("adaHours")
    public String getAdaHours() {
        return adaHours;
    }

    @JsonProperty("adaHours")
    public void setAdaHours(String adaHours) {
        this.adaHours = adaHours;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
