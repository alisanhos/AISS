package aiss.model.api;

import javax.annotation.Nonnegative.Checker;

public class InterestPlaces {

	private String id;
	private String name;
	private String description;
	private String city;
	private String score;

	
	public InterestPlaces() {
	}

	public InterestPlaces(String name, String description, String city, String score) {
		this.name = name;
		this.description = description;
		this.city = city;
		
		this.score= score;
	}
	
	public InterestPlaces(String id,String name, String description, String city,String score) {
		this.id=id;
		this.name = name;
		this.description = description;
		this.city = city;
		if(Double.parseDouble(score)>0&&Double.parseDouble(score)<5) {
			this.score= score;
		}
		else {
			System.out.println("el precio no puede mayor que 5 y menor que 0");
		}
		
		
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}


	public String getScore() {
		return score;
	}

	public void setScore(String score) {
		this.score = score;
	}


}
