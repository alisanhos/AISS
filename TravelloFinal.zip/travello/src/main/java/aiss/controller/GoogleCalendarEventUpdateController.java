package aiss.controller;

import java.io.IOException;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.api.client.util.DateTime;

import aiss.model.calendars.End;
import aiss.model.calendars.Item;
import aiss.model.calendars.Start;
import aiss.model.resource.GoogleCalendarResource;

public class GoogleCalendarEventUpdateController extends HttpServlet{
	    /**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		private static final Logger log = Logger.getLogger(GoogleCalendarEventUpdateController.class.getName());

	    @Override
	    public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
	    	
	    	String Summary = req.getParameter("Summary");
	    	String Description = req.getParameter("Description");
	    	String start = req.getParameter("start");
	    	String end = req.getParameter("end");
	    	
	    	Start st= new Start();
	    	st.setDate(start);
	    	End en= new End();
	    	en.setDate(end);
	    	
	    	Item UpdatedEvent= new Item();
	    	UpdatedEvent.setSummary(Summary);
	    	UpdatedEvent.setDescription(Description);
	    	UpdatedEvent.setStart(st);
	    	UpdatedEvent.setEnd(en);
	    	
	    	String CalendarID= req.getParameter("idcalendario");
	        String id = req.getParameter("id");
	        if (id != null && !"".equals(id) && CalendarID != null && !"".equals(CalendarID)) {
	        	
	            String accessToken = (String) req.getSession().getAttribute("GoogleCalendar-token");
	            if (accessToken != null && !"".equals(accessToken)) {
	                GoogleCalendarResource gdResource = new GoogleCalendarResource(accessToken);
	                gdResource.updateEvent(UpdatedEvent, CalendarID, id);
	                log.info("Event with id '" + id + "' updated!");
	                req.getRequestDispatcher("/googleCalendarListEvent?id="+CalendarID).forward(req, resp);
	            } else {
	                log.info("Trying to access Google Calendar without an access token, redirecting to OAuth servlet");
	                req.getRequestDispatcher("/AuthController/GoogleCalendar").forward(req, resp);
	            }
	        } else {
	            log.warning("Invalid id for update!");
	            req.getRequestDispatcher("/googleCalendarFileList").forward(req, resp);
	        }
	    }

	    @Override
	    public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
	    	doGet(req, resp);
	    }
	}


