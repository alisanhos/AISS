package aiss.controller;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import aiss.model.resource.TiempoResource;
import aiss.model.weather.ClimaSearch;

public class TiempoController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private static final Logger log = Logger.getLogger(TiempoController.class.getName());
	 
   
    public TiempoController() {
        super();
    }
    
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {	
		
		String ciudad = request.getParameter("ciudad");
		ciudad = capitalize(ciudad);
		RequestDispatcher rd = null;
		
		// Search for weather in OpenWeatherMap
		log.log(Level.FINE, "Searching for weather in " + ciudad);
		TiempoResource tiempo = new TiempoResource();
		ClimaSearch climaResults = tiempo.getClima(ciudad);

		if (climaResults!=null){
			rd = request.getRequestDispatcher("/2pantalla.jsp?ciudad="+ciudad);
			request.setAttribute("clima", climaResults.getWeather());		
		} else {
			log.log(Level.SEVERE, "Weather object: " + climaResults);
			rd = request.getRequestDispatcher("/error.jsp");
		}
		rd.forward(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
	public String capitalize(String ciudad) {
		String res = ciudad.substring(0, 1).toUpperCase() + ciudad.substring(1);;
		return res;
	}
	
}

