package aiss.controller;

import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



import aiss.model.api.InterestPlaces;


import aiss.model.repository.MapInterestPlacesRepository;

public class InterestPlacesAddController extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8586237775504038766L;

	  public InterestPlacesAddController() {
	        super();
	    }

	  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			String name=request.getParameter("name");
			String city=request.getParameter("city");
			String score= request.getParameter("score");
			String description=request.getParameter("description");
			
			InterestPlaces s= new InterestPlaces();
			s.setCity(city);
			s.setDescription(description);
			s.setName(name);
			s.setScore(score);
		  
			// Load contacts
			MapInterestPlacesRepository repository = MapInterestPlacesRepository.getInstance();
			repository.addPlace(s);
			request.getRequestDispatcher("/InterestPlacesGratitud.jsp").forward(request, response);
		
		}
		
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			doGet(request, response);
		}
}
