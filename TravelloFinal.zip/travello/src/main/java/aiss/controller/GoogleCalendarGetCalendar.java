package aiss.controller;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import aiss.model.calendars.Calendar;
import aiss.model.calendars.Item;
import aiss.model.resource.GoogleCalendarResource;
import aiss.model.resource.TriposoResource;
import aiss.model.triposo.RestaurantsSearch;

public class GoogleCalendarGetCalendar extends HttpServlet{


		/**
		 * 
		 */
		private static final long serialVersionUID = -5106923399953153626L;
		private static final Logger log = Logger.getLogger(GoogleCalendarGetCalendar.class.getName());
		
		public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
			String summary=req.getParameter("summary");
			String fecha=req.getParameter("fecha");
			String access_token= (String) req.getSession().getAttribute("GoogleCalendar-token");
			;
			if (access_token != null && !"".equals(access_token)) {
				System.out.println(access_token);
				GoogleCalendarResource gr= new GoogleCalendarResource(access_token);
				Calendar calendar = gr.getCalendar();
				if(summary==null || "".equals(summary)) {
					if(calendar!=null) {
						req.setAttribute("calendar", calendar);
						req.getRequestDispatcher("/googleCalendarFileListing.jsp").forward(req, resp);
					}else {
						log.info("The calendar returned is null... probably your token has experied. Redirecting to OAuth servlet.");
						req.getRequestDispatcher("/AuthController/GoogleCalendar").forward(req, resp);
					}
				}else {
					if(calendar!=null) {
						req.setAttribute("summary", summary);
						req.setAttribute("fecha", fecha);
						req.setAttribute("calendar", calendar);
						req.getRequestDispatcher("/googleCalendarFileTicketAdded.jsp").forward(req, resp);
					}else {
						log.info("The calendar returned is null... probably your token has experied. Redirecting to OAuth servlet.");
						req.getRequestDispatcher("/AuthController/GoogleCalendar").forward(req, resp);
					}
				}
			}else {
	            log.info("Trying to access Google Drive without an access token, redirecting to OAuth servlet");
	            req.getRequestDispatcher("/AuthController/GoogleCalendar").forward(req, resp);
	        }
			
	   }
	        
		
		

		
		 public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		        doGet(req, resp);
		    }
	}


