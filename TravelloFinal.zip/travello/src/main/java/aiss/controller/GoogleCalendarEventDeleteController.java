package aiss.controller;

import java.io.IOException;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import aiss.model.resource.GoogleCalendarResource;

public class GoogleCalendarEventDeleteController extends HttpServlet{
	


		/**
	 * 
	 */
	private static final long serialVersionUID = 6301912555383200688L;
		private static final Logger log = Logger.getLogger(GoogleCalendarEventDeleteController.class.getName());

	    @Override
	    public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
	    	
	    	String CalendarID=req.getParameter("calendarid");
	        String Eventid = req.getParameter("id");
	        if (Eventid != null && !"".equals(Eventid)||CalendarID != null && !"".equals(CalendarID)) {
	            String accessToken = (String) req.getSession().getAttribute("GoogleCalendar-token");
	            if (accessToken != null && !"".equals(accessToken)) {
	                GoogleCalendarResource gdResource = new GoogleCalendarResource(accessToken);
	                gdResource.deleteEvent(CalendarID,Eventid);
	                log.info("Event with id '" + Eventid + "' deleted!");
	                req.getRequestDispatcher("/googleCalendarListEvent?id="+CalendarID).forward(req, resp);
	            } else {
	                log.info("Trying to access Google Drive without an access token, redirecting to OAuth servlet");
	                req.getRequestDispatcher("/AuthController/GoogleCalendar").forward(req, resp);
	            }
	        } else {
	            log.warning("Invalid id for delete!");
	            req.getRequestDispatcher("/googleCalendarEventListing").forward(req, resp);
	        }
	    }
	}

