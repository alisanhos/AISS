package aiss.controller;

import java.io.IOException;
import java.util.Collection;

import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import aiss.model.api.InterestPlaces;
import aiss.model.repository.MapInterestPlacesRepository;


public class InterestPlacesListController extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8319710405246811009L;
	private static final Logger log = Logger.getLogger(InterestPlacesListController.class.getName());

	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		MapInterestPlacesRepository repository = MapInterestPlacesRepository.getInstance();
		Collection<InterestPlaces> places = repository.getAllPlaces();
	        
	       
	         	if (places != null) {
	         		req.setAttribute("list", places);
	         		req.getRequestDispatcher("/InterestPlacesBlog.jsp").forward(req, resp);
	         	} else {
	         		log.info("You can't pass.");
	         		req.getRequestDispatcher("/error.jsp").forward(req, resp);
	         	}
	         	
	        
	        
	    }

	    public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
	        doGet(req, resp);
	    }
}
