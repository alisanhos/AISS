package aiss.api.resouces.comparators;

import java.util.Comparator;

import aiss.model.api.InterestPlaces;

public class ComparatorScorePlacesReversed implements Comparator<InterestPlaces>{

	@Override
	public int compare(InterestPlaces o1, InterestPlaces o2) {
		
		return o2.getScore().compareTo(o1.getScore());
	}

}
