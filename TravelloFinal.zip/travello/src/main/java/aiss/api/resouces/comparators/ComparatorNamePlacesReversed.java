package aiss.api.resouces.comparators;

import java.util.Comparator;

import aiss.model.api.InterestPlaces;

public class ComparatorNamePlacesReversed implements Comparator<InterestPlaces>{

	@Override
	public int compare(InterestPlaces o1, InterestPlaces o2) {
		return o2.getName().compareTo(o1.getName());
	}
	
}
