package aiss.api.resources;

import java.net.URI;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.core.Response.ResponseBuilder;

import org.jboss.resteasy.spi.BadRequestException;
import org.jboss.resteasy.spi.NotFoundException;

import aiss.api.resouces.comparators.ComparatorNamePlaces;
import aiss.api.resouces.comparators.ComparatorNamePlacesReversed;
import aiss.api.resouces.comparators.ComparatorScorePlaces;
import aiss.api.resouces.comparators.ComparatorScorePlacesReversed;
import aiss.model.api.InterestPlaces;
import aiss.model.repository.MapInterestPlacesRepository;



@Path("/places")
public class InterestPlacesResource {



	public static InterestPlacesResource _instance=null;
	MapInterestPlacesRepository repository;
	
	public InterestPlacesResource(){
		repository=MapInterestPlacesRepository.getInstance();
	}
	
	public static InterestPlacesResource getInstance()
	{
		if(_instance==null)
			_instance=new InterestPlacesResource();
		return _instance; 
	}
	
	@GET
	@Produces("application/json")
	public Collection<InterestPlaces> getAll(@QueryParam("order") String order, @QueryParam("q") String q)
	{
		List<InterestPlaces> result = new ArrayList<InterestPlaces>();
        
        for (InterestPlaces place: repository.getAllPlaces()) {
            if (q == null || place.getName().toLowerCase().contains(q.toLowerCase())||(place.getScore() != null && place.getScore().contains(q))|| (place.getCity().toLowerCase().contains(q.toLowerCase()))) {
            	result.add(place);
            }
            		
            	
        }
            
        if (order != null) { // Order results
            if (order.equals("name")) {
                Collections.sort(result, new ComparatorNamePlaces());
            } else if (order.equals("-name")) {
            	Collections.sort(result, new ComparatorNamePlacesReversed());
            } else if (order.equals("score")) {
            	Collections.sort(result, new ComparatorScorePlaces());
            } else if (order.equals("-score")) {
            	Collections.sort(result, new ComparatorScorePlacesReversed());
            } else {
                throw new BadRequestException("The order parameter must be 'name', '-name, 'score' or '-score'.");
            }
        }

        return result;
	}
	
	
	@GET
	@Path("/{id}")
	@Produces("application/json")
	public InterestPlaces get(@PathParam("id") String placeId)
	{
		InterestPlaces place = repository.getPlace(placeId);
		
		if (place == null) {
			throw new NotFoundException("The place with id="+ placeId +" was not found");			
		}
		
		return place;
	}
	
	@POST
	@Consumes("application/json")
	@Produces("application/json")
	public Response addPlace(@Context UriInfo uriInfo, InterestPlaces place) {
		if (place.getName() == null || "".equals(place.getName()))
			throw new BadRequestException("The name of the place must not be null");

		repository.addPlace(place);

		UriBuilder ub = uriInfo.getAbsolutePathBuilder().path(this.getClass(), "get");
		URI uri = ub.build(place.getId());
		ResponseBuilder resp = Response.created(uri);
		resp.entity(place);			
		return resp.build();
	}
	
	
	@PUT
	@Consumes("application/json")
	public Response updatePlace(InterestPlaces place) {
		InterestPlaces oldplace = repository.getPlace(place.getId());
		if (oldplace == null) {
			throw new NotFoundException("The song with id="+ place.getId() +" was not found");			
		}
		
		// Update name
		if (place.getName()!=null)
			oldplace.setName(place.getName());
		
		// Update description
		if (place.getDescription()!=null)
			oldplace.setDescription(place.getDescription());
		
		// Update city
		if (place.getCity()!=null)
			oldplace.setCity(place.getCity());
		
		// Update score
		if (place.getScore()!=null)
			oldplace.setScore(place.getScore());
		
	
		
		return Response.noContent().build();
	}
	
	@DELETE
	@Path("/{id}")
	public Response removePlace(@PathParam("id") String placeId) {
		InterestPlaces toberemoved=repository.getPlace(placeId);
		if (toberemoved == null)
			throw new NotFoundException("The place with id="+ placeId +" was not found");
		else
			repository.deletePlace(placeId);
		
		return Response.noContent().build();
	}
}
