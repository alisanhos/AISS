package aiss.model.resource;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import java.io.UnsupportedEncodingException;
import org.junit.Test;
import aiss.model.ticketmaster.TicketSearch;

public class TMasterTest {
	@Test
	public void test() throws UnsupportedEncodingException {
		String city = "Madrid";
		TicketResource tmaster = new TicketResource();
		TicketSearch ticketResults = tmaster.getTicketMasterEvents(city);
		
		assertNotNull("The search returned null", ticketResults);
		assertNotNull("The search returned null", ticketResults.getEmbedded().getEvents());
		assertFalse("The number of restaurants for "+ city + " is zero", ticketResults.getEmbedded().getEvents().size()==0);
		
		System.out.println("The search for " + city + "'s events returned " + ticketResults.getEmbedded().getEvents().size() + " events.");
	}
}
