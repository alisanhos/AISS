package aiss.model.resource;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import aiss.model.calendars.*;
import aiss.model.resource.*;


import java.io.UnsupportedEncodingException;

import org.junit.Test;
import org.restlet.data.ChallengeResponse;
import org.restlet.data.ChallengeScheme;
import org.restlet.resource.ClientResource;



public class CalendarTest {

	public static String access_token="ya29.a0AfH6SMC3qbk5XI_Cay4MPhP5G-l632gwox3kr_Tf1zthjJzExMlk7mJSg5r7B_zBrhUZ-EomxC88RAp3UzNmjMD4o8-2Jw63_vqKeRy9y-YQ4cGJvBGsWQOTT9Kh4atpAqvFNKV1p3-nHgT129u-5L6XMs8B-EsMPFI";
	
//	@Test
//	public void InsertEventTest() throws UnsupportedEncodingException {
//		String summary="test";
//		String descripcion="esto es una prueba";
//		String dateini="2020-05-01";
//		String dateend="2020-05-01";
//		String calendarID= "a6pri8q9juqvdmdnrearl5f3tc@group.calendar.google.com";
//		GoogleCalendarResource gr= new GoogleCalendarResource(access_token);
//		Item event= gr.insertEventInCalendar(calendarID, summary, descripcion, dateini, dateend);
//		assertNotNull(event);
//		System.out.println(event.getStart().getDate());
//	}
	
//	@Test
//	public void getCalendarList() throws UnsupportedEncodingException{
//		String calendarID= "e3a9s3htqo9v93de5i98bcetgg@group.calendar.google.com";
//		GoogleCalendarResource gr= new GoogleCalendarResource(access_token);
//		Events ls= gr.getListEvents(calendarID);
//		assertNotNull(ls);
//		System.out.println(ls);
//	}
	
//	@Test
//	public void AssertDeleteEvent() throws UnsupportedEncodingException{
//		String eventID="coe534buoren2dqm4a5krs3ke0";
//		String calendarID= "nallg1afgoe648ihi2ip3k0fe8@group.calendar.google.com";
//		GoogleCalendarResource gr= new GoogleCalendarResource(access_token);
//		boolean ls= gr.deleteEvent(calendarID,eventID);
//		System.out.println(ls);
//		assertTrue(ls);
//		
//	}
	
//	@Test
//	public void AssertUpdateEvent() throws UnsupportedEncodingException{
//		
//		String eventID="5hqkfvuefjtols066tt23veh88";
//		String calendarID= "ls91u7pd3quptr7u6iqbs72h3c@group.calendar.google.com";
//		GoogleCalendarResource gr= new GoogleCalendarResource(access_token);
//		Item evento= new Item();
//		evento.setSummary("prueba");
//		evento.setDescription("funciona");
//		Start start= new Start();
//		start.setDate("2020-05-01");
//		End end= new End();
//		end.setDate("2020-05-01");
//		evento.setStart(start);
//		evento.setEnd(end);
//		
//		boolean ls= gr.updateEvent(evento, calendarID, eventID);
//		System.out.println(ls);
//		assertTrue(ls);
//	}
//	
//	@Test
//	public void getCalendar() throws UnsupportedEncodingException{
//		String calendarID= "jmtr2000@gmail.com";
//		GoogleCalendarResource gr= new GoogleCalendarResource(access_token);
//		Events ls= gr.getListEvents(calendarID);
//		assertNotNull(ls);
//		
//	}
}


