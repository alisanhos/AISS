package aiss.model.resource;

import static org.junit.Assert.assertNotNull;
import java.io.UnsupportedEncodingException;
import org.junit.Test;
import aiss.model.weather.ClimaSearch;

public class WeatherTest {
	@Test
	public void test() throws UnsupportedEncodingException {
		String city = "Madrid";
		TiempoResource tiempo = new TiempoResource();
		ClimaSearch tiempoResults = tiempo.getClima(city);
		
		assertNotNull("The search returned null", tiempoResults);
		assertNotNull("The search returned null", tiempoResults.getWeather());
		assertNotNull("The search returned null", tiempoResults.getWeather().get(0));
		assertNotNull("The search returned null", tiempoResults.getWeather().get(0).getDescription());

		System.out.println("The search for " + city + "'s weather returned a " + tiempoResults.getWeather().get(0).getDescription() + ".");
	}
}
