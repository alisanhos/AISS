package aiss.model.resource;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import java.io.UnsupportedEncodingException;

import org.junit.Test;

import aiss.model.triposo.RestaurantsSearch;

public class TriposoTest {
	@Test
	public void test() throws UnsupportedEncodingException {
		String city = "Madrid";
		TriposoResource triposo = new TriposoResource();
		RestaurantsSearch triposoResults = triposo.getTriposoRestaurants(city);
		
		assertNotNull("The search returned null", triposoResults);
		assertNotNull("The search returned null", triposoResults.getResults());
		assertFalse("The number of restaurants for "+ city + " is zero", triposoResults.getResults().size()==0);
		
		System.out.println("The search for " + city + "'s restaurants returned " + triposoResults.getResults().size() + " restaurants.");
	}
}
