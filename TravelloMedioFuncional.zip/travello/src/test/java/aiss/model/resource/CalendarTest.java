package aiss.model.resource;

import static org.junit.Assert.assertNotNull;
import aiss.model.calendars.*;
import aiss.model.resource.*;


import java.io.UnsupportedEncodingException;

import org.junit.Test;
import org.restlet.data.ChallengeResponse;
import org.restlet.data.ChallengeScheme;
import org.restlet.resource.ClientResource;

import aiss.model.calendars.Calendar;



public class CalendarTest {

//	@Test
//	public void getMoviesTest() throws UnsupportedEncodingException {
//		String CalendarId="jmtr2000@gmail.com";
//		String token="https://oauth2.googleapis.com/token";
//		CalendarResource cr = new CalendarResource(token);
//		Calendar results=cr.getCalendar(CalendarId);
//		
//		assertNotNull("The search returned null", results);
//		
//	}
//	@Test
//	public void getIdTest() throws UnsupportedEncodingException {
//
////		String access_token="ya29.a0Ae4lvC0UloLK2eEbAUfgSqalUlAhSzaNf7LE7WXcMFzpckm3tEsEINUkiuLypiWHdrIgqDPBLxJ7JQZrpd2eDASevNpkyZyai6tBmZ1Zrb5pBt7whwfaUUH_wKuU2aFwn4tZWE_oVLJRGGD8AOv6USTJSob9Cx0KMphRoxiM";	
////		ClientResource cr=new ClientResource("https://content.googleapis.com/calendar/v3/calendars?alt=json");
////		ChallengeResponse chr = new ChallengeResponse(ChallengeScheme.HTTP_OAUTH_BEARER);
////		chr.setRawValue(access_token);
////		cr.setChallengeResponse(chr);
////		Calendar datosParaCrear=new Calendar();
////		datosParaCrear.setSummary("Prueba refinitiva");
////		Calendar contenido=cr.post(datosParaCrear,Calendar.class);
////		assertNotNull("The search returned null", contenido);
////		System.out.println(contenido.getSummary());
//		GoogleCalendarResource cr = new GoogleCalendarResource("ya29.a0Ae4lvC0aZbPrJnKF9_IQZadwheY8mHl7fXErTjO2f9LqJUe-5h1WUcTyzJl6kwZGcSeUGZjacpqYERXmITmjHSP0YcJRdywUJF2t7ZxBYm3MbMJ1KEruU10VSbNpvvnv0N7Cntmn3q1cEB7KM4N-EOwn_1wIS5tF6fF7");
//		
//		
//		cr.insertCalendar("troleado put0");
//		System.out.println(cr.insertCalendar("troleado put0"));
//		
//	}
//	@Test
//	public void getIdTest() throws UnsupportedEncodingException {
//
//		String calendarID= "ispe21mtp9lodqoa63sst89fak@group.calendar.google.com";
//		String access_token= "ya29.a0Ae4lvC029gzdOQ-tfxfwndW5Fkuc7Yf0os2hX6VgvL9tTyTrf7cWFzCROChmowXHn5QRy8clOr-wJBdcm8kj3BPEC-A3cxC3hQ9ow_adpee0GTNb7wdKtGJ_1wEBpDvvbRVS_QbmhV7-vc6uuOhitOPpR6yzyC0IU_Za";
//		GoogleCalendarResource gr= new GoogleCalendarResource(access_token);
//		EventCalendar event= gr.insertEventInCalendar(calendarID);
//		assertNotNull(event);
//		System.out.println(event.getStart().getDateTime());
//	}

}


