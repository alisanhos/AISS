package aiss.model.resource;


import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.logging.Logger;
import org.restlet.data.ChallengeResponse;
import org.restlet.data.ChallengeScheme;
import org.restlet.data.MediaType;
import org.restlet.resource.ClientResource;
import org.restlet.resource.ResourceException;

import com.google.api.client.util.DateTime;

import aiss.model.calendars.Calendar;
import aiss.model.calendars.End;
import aiss.model.calendars.EventCalendar;
import aiss.model.calendars.Start;



public class GoogleCalendarResource {
	
	  private static final Logger log = Logger.getLogger(GoogleCalendarResource.class.getName());

	  private final String access_token;
	  private final String baseURL = "https://content.googleapis.com/calendar/v3/calendars?alt=json";

	  public GoogleCalendarResource(String access_token) {
	        this.access_token = access_token;
	    }
	  public Calendar insertCalendar(String sumara) {	
			ClientResource cr=new ClientResource(baseURL);
			ChallengeResponse chr = new ChallengeResponse(ChallengeScheme.HTTP_OAUTH_BEARER);
			chr.setRawValue(access_token);
			cr.setChallengeResponse(chr);
			Calendar datosParaCrear=new Calendar();
			datosParaCrear.setSummary(sumara);
			Calendar contenido=cr.post(datosParaCrear,Calendar.class);
			return contenido;

	  }
	  public EventCalendar insertEventInCalendar(String CalendarId) throws UnsupportedEncodingException{
		  //String queryFormatted=URLEncoder.encode(CalendarId,"UTF-8");
		  DateTime startDateTime = new DateTime ( "2020-05-01T11:35:36.000Z" );
		  DateTime endDateTime = new DateTime ( "2020-05-01T16:18:27.000Z" );  
		  
		  //ClientResource cr=new ClientResource(baseURL+ "/"+CalendarId+"/events?alt=json");
		  ClientResource cr=new ClientResource("https://content.googleapis.com/calendar/v3/calendars/ispe21mtp9lodqoa63sst89fak%40group.calendar.google.com/events?alt=json");
		  ChallengeResponse chr = new ChallengeResponse(ChallengeScheme.HTTP_OAUTH_BEARER);
		  chr.setRawValue(access_token);
		  cr.setChallengeResponse(chr);
		  
		  EventCalendar evento=new EventCalendar();
		  End end= new End();
		  end.setDateTime(endDateTime.toStringRfc3339());
		  Start start = new Start();
		  start.setDateTime(startDateTime.toStringRfc3339());
		  evento.setStart(start);
		  evento.setEnd(end);
		  EventCalendar contenido=cr.post(evento,EventCalendar.class);
		  return contenido;

	  }
}
