
package aiss.model.triposo;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "name",
    "coordinates",
    "score",
    "images",
    "poitype-Restaurant_score"
})
public class Result {

    @JsonProperty("name")
    private String name;
    @JsonProperty("coordinates")
    private Coordinates coordinates;
    @JsonProperty("score")
    private Double score;
    @JsonProperty("images")
    private List<Image> images = null;
    @JsonProperty("poitype-Restaurant_score")
    private Double poitypeRestaurantScore;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("name")
    public String getName() {
        return name;
    }

    @JsonProperty("name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("coordinates")
    public Coordinates getCoordinates() {
        return coordinates;
    }

    @JsonProperty("coordinates")
    public void setCoordinates(Coordinates coordinates) {
        this.coordinates = coordinates;
    }

    @JsonProperty("score")
    public Double getScore() {
        return score;
    }

    @JsonProperty("score")
    public void setScore(Double score) {
        this.score = score;
    }

    @JsonProperty("images")
    public List<Image> getImages() {
        return images;
    }

    @JsonProperty("images")
    public void setImages(List<Image> images) {
        this.images = images;
    }

    @JsonProperty("poitype-Restaurant_score")
    public Double getPoitypeRestaurantScore() {
        return poitypeRestaurantScore;
    }

    @JsonProperty("poitype-Restaurant_score")
    public void setPoitypeRestaurantScore(Double poitypeRestaurantScore) {
        this.poitypeRestaurantScore = poitypeRestaurantScore;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
