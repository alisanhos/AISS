
package aiss.model.triposo;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "format",
    "attribution_text",
    "attribution_link",
    "license_text",
    "license_link"
})
public class Attribution {

    @JsonProperty("format")
    private String format;
    @JsonProperty("attribution_text")
    private String attributionText;
    @JsonProperty("attribution_link")
    private String attributionLink;
    @JsonProperty("license_text")
    private Object licenseText;
    @JsonProperty("license_link")
    private Object licenseLink;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("format")
    public String getFormat() {
        return format;
    }

    @JsonProperty("format")
    public void setFormat(String format) {
        this.format = format;
    }

    @JsonProperty("attribution_text")
    public String getAttributionText() {
        return attributionText;
    }

    @JsonProperty("attribution_text")
    public void setAttributionText(String attributionText) {
        this.attributionText = attributionText;
    }

    @JsonProperty("attribution_link")
    public String getAttributionLink() {
        return attributionLink;
    }

    @JsonProperty("attribution_link")
    public void setAttributionLink(String attributionLink) {
        this.attributionLink = attributionLink;
    }

    @JsonProperty("license_text")
    public Object getLicenseText() {
        return licenseText;
    }

    @JsonProperty("license_text")
    public void setLicenseText(Object licenseText) {
        this.licenseText = licenseText;
    }

    @JsonProperty("license_link")
    public Object getLicenseLink() {
        return licenseLink;
    }

    @JsonProperty("license_link")
    public void setLicenseLink(Object licenseLink) {
        this.licenseLink = licenseLink;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
