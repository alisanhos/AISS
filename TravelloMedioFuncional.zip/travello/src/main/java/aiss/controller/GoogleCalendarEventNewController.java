package aiss.controller;

import java.io.IOException;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import aiss.model.calendars.Calendar;
import aiss.model.calendars.EventCalendar;
import aiss.model.resource.GoogleCalendarResource;

public class GoogleCalendarEventNewController extends HttpServlet{
	/**
	 * 
	 */
	private static final long serialVersionUID = -7730423515116412601L;
	private static final Logger log = Logger.getLogger(GoogleCalendarEventNewController.class.getName());
	
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		String access_token= (String) req.getSession().getAttribute("GoogleCalendar-token");
		String id=req.getParameter("id");
		if (access_token != null && !"".equals(access_token)) {
			GoogleCalendarResource gr= new GoogleCalendarResource(access_token);
			
			EventCalendar evento = gr.insertEventInCalendar(id);
			
			if(evento!=null) {
				req.setAttribute("evento", evento);
                req.getRequestDispatcher("EventSuccess.jsp").forward(req, resp);
			}else {
                log.info("The calendar returned is null... probably your token has experied. Redirecting to OAuth servlet.");
                req.getRequestDispatcher("/AuthController/GoogleCalendar").forward(req, resp);
            }
		}else {
            log.info("Trying to access Google Drive without an access token, redirecting to OAuth servlet");
            req.getRequestDispatcher("/AuthController/GoogleCalendar").forward(req, resp);
        }
		
	}

	
	 public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
	        doGet(req, resp);
	    }
}



