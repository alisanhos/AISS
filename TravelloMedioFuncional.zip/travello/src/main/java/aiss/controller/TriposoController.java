package aiss.controller;

import javax.servlet.http.HttpServlet;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import aiss.model.resource.TriposoResource;
import aiss.model.triposo.RestaurantsSearch;


/**
 * Servlet implementation class SearchController
 */
public class TriposoController extends HttpServlet{
	private static final long serialVersionUID = 1L;
       
	private static final Logger log = Logger.getLogger(TriposoController.class.getName());
	 
//    public SearchController() {
//        super();}
    
	
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {	
		
		String query = request.getParameter("city");
		RequestDispatcher rd = null;
		
		
		// Search for restaurants in Triposo
		log.log(Level.FINE, "Searching for restaurants in " + query);
		TriposoResource restaurant = new TriposoResource();
		RestaurantsSearch restaurantsResults = restaurant.getTriposoRestaurants(query);

		if (restaurantsResults!=null){
			rd = request.getRequestDispatcher("/restaurantSuccess.jsp");
			request.setAttribute("restaurant", restaurantsResults.getResults());		
		} else {
			log.log(Level.SEVERE, "Restaurant object: " + restaurantsResults);
			rd = request.getRequestDispatcher("/error.jsp");
		}
		rd.forward(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
}
